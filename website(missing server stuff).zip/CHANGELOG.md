View the changelog on the [OctoberCMS website](https://octobercms.com/changelog)
