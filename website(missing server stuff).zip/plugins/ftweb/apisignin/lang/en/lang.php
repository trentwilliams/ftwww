<?php return [
    'plugin' => [
        'name' => 'apisignin',
        'description' => ''
    ]
];