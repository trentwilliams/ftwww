<?php namespace RainLab\Builder\Models;

class MyMock
{
    public $table = 'my_mock_table';
}
