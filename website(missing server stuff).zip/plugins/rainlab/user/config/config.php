<?php return [
      /*
      |--------------------------------------------------------------------------
      | Minimum Password Length
      |--------------------------------------------------------------------------
      |
      | The minimum length of characters required for user passwords.
      |
      */
    'minPasswordLength' => 8,
];
