<?php 
class Cms5fd6cf21d4e54016803880_3ffbb724a47b209e2e424701e3948580Class extends Cms\Classes\PageCode
{

}
