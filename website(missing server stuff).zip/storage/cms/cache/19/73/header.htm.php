<?php 
class Cms5fd6cef024952683847423_e1807ffb0c4583a962929c0faa5269c1Class extends Cms\Classes\PartialCode
{
public function onStart()
{
    $this['backendUrl'] = Backend::url('/');
}
}
