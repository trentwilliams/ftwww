<?php 
class Cms5fd69d149e676324253673_74d0b4ee8e461aeb7d5e01daf15d6fc4Class extends Cms\Classes\PageCode
{

}
