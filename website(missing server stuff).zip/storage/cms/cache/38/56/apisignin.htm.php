<?php 
class Cms5fd6cbecd0eab987084540_335cbb063f4a3bcaf20b21f46ca50911Class extends Cms\Classes\PartialCode
{

}
