<?php 
class Cms5fd680c1dea70343203297_7d80e50b964eac52174d5644f0da0f3aClass extends Cms\Classes\PageCode
{

}
