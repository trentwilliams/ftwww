<?php 
class Cms5fd69b20b4384735978447_bb316c6f5133e93755a805a5aa268086Class extends Cms\Classes\PageCode
{

}
