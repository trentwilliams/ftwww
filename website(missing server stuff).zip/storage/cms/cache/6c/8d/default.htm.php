<?php 
class Cms5fd680bf233a4973301583_1c4545e9f3f1c7656b5d7c62b0e03a71Class extends Cms\Classes\LayoutCode
{

}
