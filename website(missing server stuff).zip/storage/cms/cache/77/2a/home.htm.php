<?php 
class Cms5fd6ce9bd03bb317532360_265ba44fcc4c0e269db6579618df3571Class extends Cms\Classes\PageCode
{

}
