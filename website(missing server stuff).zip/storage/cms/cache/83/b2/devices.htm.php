<?php 
class Cms5fd6d19121e0d405075613_fe81cb0af74fc236aa8b47e1439c89eeClass extends Cms\Classes\PageCode
{

}
