<?php 
class Cms5fd6b13918b22108291791_81d14eea45ba3869f8cf5262f60786e9Class extends Cms\Classes\PartialCode
{

}
