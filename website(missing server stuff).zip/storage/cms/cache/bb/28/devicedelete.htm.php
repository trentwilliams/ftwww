<?php 
class Cms5fd6b0c7ddbea808380272_039973e8f61474982c38031caf989e6dClass extends Cms\Classes\PageCode
{

}
