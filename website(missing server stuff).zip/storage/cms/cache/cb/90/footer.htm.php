<?php 
class Cms5fd680bf5c490074727888_f7f8b9c352c5f7773138602c28e70252Class extends Cms\Classes\PartialCode
{

}
