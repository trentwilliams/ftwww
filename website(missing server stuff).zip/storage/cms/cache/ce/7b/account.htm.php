<?php 
class Cms5fd6b4bca8fbb202942287_dfbbc809d6ac349a2285f8f78bdc6032Class extends Cms\Classes\PageCode
{

}
