<?php 
class Cms5fd6c935a09ba027791665_62150798f60bdc14d04b0ca2a0458983Class extends Cms\Classes\PartialCode
{

}
