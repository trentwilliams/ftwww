<?php 
class Cms5fd6ce89ae656884874731_b3b6d0fccde5accd7a8192191452d24aClass extends Cms\Classes\PageCode
{

}
