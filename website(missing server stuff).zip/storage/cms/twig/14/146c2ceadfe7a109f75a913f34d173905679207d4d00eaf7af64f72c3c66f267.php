<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\pages\devicedelete.htm */
class __TwigTemplate_182e2fcdb1ef1ca1965dd60cc93892572aef60dc8a92a8e906429e0d277bab8d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array();
        $filters = array("page" => 78);
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                ['page'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<script src=\"https://unpkg.com/axios/dist/axios.min.js\"></script>

<script type=\"text/javascript\">
    //delete device
        //get passed device id
        var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var deviceIdPassed = urlParams.get('device')
    DeleteDevice();



    // call to return a list of devices
    //DeleteDevice();

    //perform ALAX request for data (as per search paramerets passed)
    function DeleteDevice() {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
        //var url = \"data/bookings.json?ci=\" + searchStart + \"&co=\" + searchEnd;
        var url = \"http://localhost:3000/device/\" + deviceIdPassed;

        //request
        xmlhttp.open(\"DELETE\", url, true);
        xmlhttp.setRequestHeader(\"Authorization\", getCookie(\"lock\"));
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                //outPut(myArr);
            }
        }
    }

    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }


    // get the details of the device
    // function outPut(arr) {
    //     var detail = \"\"
    //     var i;
    //     for (i = 0; i < arr.length; i++) {
    //         arr[1]

    //         detail = arr[i].message + \"</br>\"

    //     }
    //     // update result div on page

    //     \$(\"#detail\").html(detail)

    // }




</script>
<h2>Device removed</h2>

<p>View existing devices <a href=\"";
        // line 78
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("devices");
        echo "\">here</a></p>";
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\pages\\devicedelete.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 78,  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<script src=\"https://unpkg.com/axios/dist/axios.min.js\"></script>

<script type=\"text/javascript\">
    //delete device
        //get passed device id
        var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var deviceIdPassed = urlParams.get('device')
    DeleteDevice();



    // call to return a list of devices
    //DeleteDevice();

    //perform ALAX request for data (as per search paramerets passed)
    function DeleteDevice() {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
        //var url = \"data/bookings.json?ci=\" + searchStart + \"&co=\" + searchEnd;
        var url = \"http://localhost:3000/device/\" + deviceIdPassed;

        //request
        xmlhttp.open(\"DELETE\", url, true);
        xmlhttp.setRequestHeader(\"Authorization\", getCookie(\"lock\"));
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                //outPut(myArr);
            }
        }
    }

    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }


    // get the details of the device
    // function outPut(arr) {
    //     var detail = \"\"
    //     var i;
    //     for (i = 0; i < arr.length; i++) {
    //         arr[1]

    //         detail = arr[i].message + \"</br>\"

    //     }
    //     // update result div on page

    //     \$(\"#detail\").html(detail)

    // }




</script>
<h2>Device removed</h2>

<p>View existing devices <a href=\"{{ 'devices'|page }}\">here</a></p>", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\pages\\devicedelete.htm", "");
    }
}
