<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\pages\signin.htm */
class __TwigTemplate_683aad48293623849c61e290925b97c661898b17af2630510e335ff6fd9c8f1a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array("if" => 1, "partial" => 23);
        $filters = array("page" => 24);
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'partial'],
                ['page'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if ( !($context["user"] ?? null)) {
            // line 2
            echo "<script>

        setCookie(\"lock\",\"no\",1);


    


function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = \"expires=\" + d.toUTCString();
    document.cookie = cname + \"=\" + cvalue + \";\" + expires + \";path=/\";
}


</script>
    <div class=\"row\">

        <div class=\"col-md-6\">
            <h2>Sign in</h2>
            ";
            // line 23
            $context['__cms_partial_params'] = [];
            echo $this->env->getExtension('Cms\Twig\Extension')->partialFunction((($context["account"] ?? null) . "::signin")            , $context['__cms_partial_params']            , true            );
            unset($context['__cms_partial_params']);
            // line 24
            echo "            <p>Not a member register <a href=\"";
            echo $this->extensions['Cms\Twig\Extension']->pageFilter("register");
            echo "\">here</a></p>
        </div>



    </div>

";
        } else {
            // line 32
            echo "
    ";
            // line 33
            $context['__cms_partial_params'] = [];
            echo $this->env->getExtension('Cms\Twig\Extension')->partialFunction((($context["account"] ?? null) . "::activation_check")            , $context['__cms_partial_params']            , true            );
            unset($context['__cms_partial_params']);
            // line 34
            echo "
    ";
            // line 35
            $context['__cms_partial_params'] = [];
            echo $this->env->getExtension('Cms\Twig\Extension')->partialFunction((($context["account"] ?? null) . "::update")            , $context['__cms_partial_params']            , true            );
            unset($context['__cms_partial_params']);
            // line 36
            echo "
    ";
            // line 37
            $context['__cms_partial_params'] = [];
            echo $this->env->getExtension('Cms\Twig\Extension')->partialFunction((($context["account"] ?? null) . "::deactivate_link")            , $context['__cms_partial_params']            , true            );
            unset($context['__cms_partial_params']);
            // line 38
            echo "
";
        }
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\pages\\signin.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 38,  120 => 37,  117 => 36,  113 => 35,  110 => 34,  106 => 33,  103 => 32,  91 => 24,  87 => 23,  64 => 2,  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if not user %}
<script>

        setCookie(\"lock\",\"no\",1);


    


function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = \"expires=\" + d.toUTCString();
    document.cookie = cname + \"=\" + cvalue + \";\" + expires + \";path=/\";
}


</script>
    <div class=\"row\">

        <div class=\"col-md-6\">
            <h2>Sign in</h2>
            {% partial account ~ '::signin' %}
            <p>Not a member register <a href=\"{{ 'register'|page }}\">here</a></p>
        </div>



    </div>

{% else %}

    {% partial account ~ '::activation_check' %}

    {% partial account ~ '::update' %}

    {% partial account ~ '::deactivate_link' %}

{% endif %}", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\pages\\signin.htm", "");
    }
}
