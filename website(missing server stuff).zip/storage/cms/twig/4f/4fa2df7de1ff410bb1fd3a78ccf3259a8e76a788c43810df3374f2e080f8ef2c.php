<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\pages\devices.htm */
class __TwigTemplate_25b4bc552d35e4a73fb6d8c376c975f65e34bc04d55e4d3372521248267b6816 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array("if" => 1);
        $filters = array("page" => 124);
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['page'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["user"] ?? null)) {
            // line 2
            echo "


<script>

    // my listeners (date inputs and search button)
    \$(function () {


        GetDevices();

        //click search - fire Ajax search
        \$(\"#search\").on(\"click\", function () {
            console.log(\"sending\");
            SearchAvaliable(document.getElementById('deviceid').value);
        });


    });

    //perform ALAX request for data (as per search paramerets passed)
    function GetDevices() {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
        var url = \"http://localhost:3000/device/\";

        //request
        xmlhttp.open(\"GET\", url, true);
        xmlhttp.setRequestHeader(\"Authorization\", getCookie(\"lock\"));
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                outPut(myArr);
            }
        }
    }
// read cookier for security of api
    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }

    //perform ALAX request for data (as per search paramerets passed)
    function SearchAvaliable(deviceid) {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
         var url = \"http://localhost:3000/device/\" + deviceid;

        //request
        xmlhttp.open(\"GET\", url, true);
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                outPut(myArr);
            }
        }
    }


    //loop though array creating the outpuut string
    function outPutmessage(string) {
        var out = \"<p>\"
        out += string;
        out +=\"</p>\"

        // update result div on page
        \$(\"#results2\").html(out);
    }


    //loop though array creating the outpuut string
    function outPut(arr) {
        var out = \"\"


        out += \"<table><colgroup><col style='width: 50px'><col style='width: 200px'><col style='width: 100px'><col style='width: 80px'><col style='width: 100px'></colgroup>\";
        out += \"<thead><tr><th>ID</th><th>Device</th><th>Version</th><th>Status</th><th></th></tr></thead><tbody>\"


        var i;
        for (i = 0; i < arr.length; i++) {
            arr[1]

            //out += arr[i].device;
            //out += \"</br>\";
            out += \"<tr><td>\" + arr[i].deviceId + \"</td><td>\" + arr[i].device + \"</td><td>\" + arr[i].version + \"</td><td>\" + arr[i].status + \"</td><td><a href=device?device=\" + arr[i].deviceId + \">view</a></td></tr>\";
        }
        out += \"</tbody></table>\";
        // update result div on page
        \$(\"#results\").html(out);
    }






</script>


<h2>Devices</h2>
<p>Add a new device <a href=\"";
            // line 124
            echo $this->extensions['Cms\Twig\Extension']->pageFilter("adddevice");
            echo "\">here</a></p>
<h3>Search devices</h3>
<p>Only device 1 has data to view, search is disabled at present (while sorting more important security issues)</p>


<div id=\"results2\"></div>
<form method=\"\" action=\"\">
    <p>
        <label for=\"deviceid\">Device ID:</label>
        <input type=\"text\" id=\"deviceid\" name=\"deviceid\" minlength=\"1\" maxlength=\"10\" placeholder=\"\" pattern=\"[0-9]\"
            required />
        <input type=\"button\" id=\"search\" value=\"Search\" />
    </p>
    <p>
    <div id=\"results\"></div>
    </p>
</form>



";
        } else {
            // line 145
            echo "<h2>Devices</h2>
<p>
    You must be signed in to see your devices.
</p>
<p>Sign in <a href=\"";
            // line 149
            echo $this->extensions['Cms\Twig\Extension']->pageFilter("signin");
            echo "\">here</a></p>
";
        }
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\pages\\devices.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 149,  212 => 145,  188 => 124,  64 => 2,  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%    if user %}



<script>

    // my listeners (date inputs and search button)
    \$(function () {


        GetDevices();

        //click search - fire Ajax search
        \$(\"#search\").on(\"click\", function () {
            console.log(\"sending\");
            SearchAvaliable(document.getElementById('deviceid').value);
        });


    });

    //perform ALAX request for data (as per search paramerets passed)
    function GetDevices() {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
        var url = \"http://localhost:3000/device/\";

        //request
        xmlhttp.open(\"GET\", url, true);
        xmlhttp.setRequestHeader(\"Authorization\", getCookie(\"lock\"));
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                outPut(myArr);
            }
        }
    }
// read cookier for security of api
    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }

    //perform ALAX request for data (as per search paramerets passed)
    function SearchAvaliable(deviceid) {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
         var url = \"http://localhost:3000/device/\" + deviceid;

        //request
        xmlhttp.open(\"GET\", url, true);
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                outPut(myArr);
            }
        }
    }


    //loop though array creating the outpuut string
    function outPutmessage(string) {
        var out = \"<p>\"
        out += string;
        out +=\"</p>\"

        // update result div on page
        \$(\"#results2\").html(out);
    }


    //loop though array creating the outpuut string
    function outPut(arr) {
        var out = \"\"


        out += \"<table><colgroup><col style='width: 50px'><col style='width: 200px'><col style='width: 100px'><col style='width: 80px'><col style='width: 100px'></colgroup>\";
        out += \"<thead><tr><th>ID</th><th>Device</th><th>Version</th><th>Status</th><th></th></tr></thead><tbody>\"


        var i;
        for (i = 0; i < arr.length; i++) {
            arr[1]

            //out += arr[i].device;
            //out += \"</br>\";
            out += \"<tr><td>\" + arr[i].deviceId + \"</td><td>\" + arr[i].device + \"</td><td>\" + arr[i].version + \"</td><td>\" + arr[i].status + \"</td><td><a href=device?device=\" + arr[i].deviceId + \">view</a></td></tr>\";
        }
        out += \"</tbody></table>\";
        // update result div on page
        \$(\"#results\").html(out);
    }






</script>


<h2>Devices</h2>
<p>Add a new device <a href=\"{{ 'adddevice'|page }}\">here</a></p>
<h3>Search devices</h3>
<p>Only device 1 has data to view, search is disabled at present (while sorting more important security issues)</p>


<div id=\"results2\"></div>
<form method=\"\" action=\"\">
    <p>
        <label for=\"deviceid\">Device ID:</label>
        <input type=\"text\" id=\"deviceid\" name=\"deviceid\" minlength=\"1\" maxlength=\"10\" placeholder=\"\" pattern=\"[0-9]\"
            required />
        <input type=\"button\" id=\"search\" value=\"Search\" />
    </p>
    <p>
    <div id=\"results\"></div>
    </p>
</form>



{% else %}
<h2>Devices</h2>
<p>
    You must be signed in to see your devices.
</p>
<p>Sign in <a href=\"{{ 'signin'|page }}\">here</a></p>
{% endif %}", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\pages\\devices.htm", "");
    }
}
