<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\partials\site\header.htm */
class __TwigTemplate_ca1fa3a3b3c230a0884c1cf207a974c5c892fd95931b8cfa0d610b85933642ca extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array("if" => 20);
        $filters = array("page" => 11);
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['page'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Nav -->
<nav id=\"layout-nav\" class=\"navbar navbar-inverse navbar-fixed-top navbar-autohide\" role=\"navigation\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-main-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"";
        // line 11
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("index");
        echo "\" style=\"font-family: 'Oxanium', cursive; font-size: 42px;\">acarium</a>
            
            <!-- <a class=\"navbar-brand\" href=\"";
        // line 13
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("index");
        echo "\" style=\"font-family: 'Mina', sans-serif; font-weight: 400; font-size: 30px;\">acarium</a> -->
            

        </div>
        <div class=\"collapse navbar-collapse navbar-main-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"separator hidden-xs\"></li>
                <li class=\"";
        // line 20
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 20), "id", [], "any", false, false, true, 20) == "index")) {
            echo "active";
        }
        echo "\"><a href=\"";
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("index");
        echo "\">Home</a></li>
                

                
                <li class=\"";
        // line 24
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 24), "id", [], "any", false, false, true, 24) == "contact")) {
            echo "active";
        }
        echo "\"><a href=\"";
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("contact");
        echo "\">Contact Us</a></li>
                
                <li class=\"";
        // line 26
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 26), "id", [], "any", false, false, true, 26) == "devices")) {
            echo "active";
        }
        echo "\"><a href=\"";
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("devices");
        echo "\">Devices</a></li>
                ";
        // line 27
        if (($context["user"] ?? null)) {
            // line 28
            echo "
                <li class=\"";
            // line 29
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 29), "id", [], "any", false, false, true, 29) == "account")) {
                echo "active";
            }
            echo "\"><a href=\"";
            echo $this->extensions['Cms\Twig\Extension']->pageFilter("account");
            echo "\">Account</a></li>
                <li><a data-request=\"onLogout\" data-request-data=\"redirect: '/signin'\">Sign out</a></li>
                ";
        } else {
            // line 32
            echo "                <li class=\"";
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 32), "id", [], "any", false, false, true, 32) == "signin")) {
                echo "active";
            }
            echo "\"><a href=\"";
            echo $this->extensions['Cms\Twig\Extension']->pageFilter("signin");
            echo "\">Sign in</a></li>
                
                ";
        }
        // line 34
        echo "                
                
            </ul>
        </div>
    </div>
</nav>";
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\site\\header.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 34,  132 => 32,  122 => 29,  119 => 28,  117 => 27,  109 => 26,  100 => 24,  89 => 20,  79 => 13,  74 => 11,  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- Nav -->
<nav id=\"layout-nav\" class=\"navbar navbar-inverse navbar-fixed-top navbar-autohide\" role=\"navigation\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-main-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"{{ 'index'|page }}\" style=\"font-family: 'Oxanium', cursive; font-size: 42px;\">acarium</a>
            
            <!-- <a class=\"navbar-brand\" href=\"{{ 'index'|page }}\" style=\"font-family: 'Mina', sans-serif; font-weight: 400; font-size: 30px;\">acarium</a> -->
            

        </div>
        <div class=\"collapse navbar-collapse navbar-main-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"separator hidden-xs\"></li>
                <li class=\"{% if this.page.id == 'index' %}active{% endif %}\"><a href=\"{{ 'index'|page }}\">Home</a></li>
                

                
                <li class=\"{% if this.page.id == 'contact' %}active{% endif %}\"><a href=\"{{ 'contact'|page }}\">Contact Us</a></li>
                
                <li class=\"{% if this.page.id == 'devices' %}active{% endif %}\"><a href=\"{{ 'devices'|page }}\">Devices</a></li>
                {% if user %}

                <li class=\"{% if this.page.id == 'account' %}active{% endif %}\"><a href=\"{{ 'account'|page }}\">Account</a></li>
                <li><a data-request=\"onLogout\" data-request-data=\"redirect: '/signin'\">Sign out</a></li>
                {% else %}
                <li class=\"{% if this.page.id == 'signin' %}active{% endif %}\"><a href=\"{{ 'signin'|page }}\">Sign in</a></li>
                
                {% endif %}                
                
            </ul>
        </div>
    </div>
</nav>", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\site\\header.htm", "");
    }
}
