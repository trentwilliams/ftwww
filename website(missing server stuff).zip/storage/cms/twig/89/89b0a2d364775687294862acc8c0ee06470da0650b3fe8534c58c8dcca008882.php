<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\partials\chartData.htm */
class __TwigTemplate_b912f15a2eb354c3f151b97061a1ef5a3242f67a8dc7bc03b3aad50ff0acf146 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array();
        $filters = array("page" => 120);
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                ['page'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<script>

    //get passed device id
    var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var deviceIdPassed = urlParams.get('device')

    // call to return a list of devices
    GetDevices();

    //perform ALAX request for data (as per search paramerets passed)
    function GetDevices() {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
        //var url = \"data/bookings.json?ci=\" + searchStart + \"&co=\" + searchEnd;
        var url = \"http://localhost:3000/device/\" + deviceIdPassed;

        //request
        xmlhttp.open(\"GET\", url, true);
        xmlhttp.setRequestHeader(\"Authorization\", getCookie(\"lock\"));
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                outPut(myArr);
            }
        }
    }

    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }

    //get the details of the device
    function outPut(arr) {
        var header = \"\"
        var detail = \"\"
        var deletelink = \"<p>To remove this device click \"
        var i;
        for (i = 0; i < arr.length; i++) {
            arr[1]

            header = \"<h1>Device: \" + arr[i].device + \"</h1>\"
            detail += \"Version: \" + arr[i].version + \"</br>\"
            detail += \"Status: \" + arr[i].status + \"</p>\"
            deletelink += \"<a href=devicedelete?device=\" + deviceIdPassed + \">here</a>.  Device will instantly be removed.</p>\"
        }
        // update result div on page
        \$(\"#header\").html(header)
        \$(\"#detail\").html(detail)
        \$(\"#delete\").html(deletelink)
    }

    // draw the graph
    window.onload = function () {

        //request the data from the API based on the device ID
        \$.getJSON(\"http://localhost:3000/sensor/\" + deviceIdPassed, addData);

        // array use dot store data
        var dataPoints = [];

        var chart = new CanvasJS.Chart(\"chartContainer\", {
            animationEnabled: true,
            //zoomEnabled: true,
            theme: \"light2\",
            title: {
                text: \"Temperature\"
            },
            axisY: {
                title: \"Degrees C°\",
                titleFontSize: 24,
                includeZero: false,

            },
            data: [{
                type: \"line\",
                yValueFormatString: \"#,### C°\",
                dataPoints: dataPoints
            }]
        });

        // write data to datapoints array (used to draw graph) then draw 
        function addData(data) {
            for (var i = 0; i < data.length; i++) {
                dataPoints.push({
                    x: new Date(data[i].date),
                    y: data[i].value
                });
            }
            chart.render();

        }



    }
</script>


<p>
<div id=\"header\"></div>

<p>View all devices <a href=\"";
        // line 120
        echo $this->extensions['Cms\Twig\Extension']->pageFilter("devices");
        echo "\">here</a></p>
<div id=\"detail\"></div>






<h2>Current Status</h2>
<p>
<div id=\"chartContainer\" style=\"height: 300px; width: 100%;\"></div>
<p></p>
<p>You can delete devices, just please dont' delete devices 1,2,or 3, please add one then delete it</p>


<div id=\"delete\"></div>

</p>";
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\chartData.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 120,  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<script>

    //get passed device id
    var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var deviceIdPassed = urlParams.get('device')

    // call to return a list of devices
    GetDevices();

    //perform ALAX request for data (as per search paramerets passed)
    function GetDevices() {

        //create the http xml object and url
        var xmlhttp = new XMLHttpRequest();
        //var url = \"data/bookings.json?ci=\" + searchStart + \"&co=\" + searchEnd;
        var url = \"http://localhost:3000/device/\" + deviceIdPassed;

        //request
        xmlhttp.open(\"GET\", url, true);
        xmlhttp.setRequestHeader(\"Authorization\", getCookie(\"lock\"));
        xmlhttp.send();

        // listen for successful (200)
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                console.log(this.responseText);
                outPut(myArr);
            }
        }
    }

    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }

    //get the details of the device
    function outPut(arr) {
        var header = \"\"
        var detail = \"\"
        var deletelink = \"<p>To remove this device click \"
        var i;
        for (i = 0; i < arr.length; i++) {
            arr[1]

            header = \"<h1>Device: \" + arr[i].device + \"</h1>\"
            detail += \"Version: \" + arr[i].version + \"</br>\"
            detail += \"Status: \" + arr[i].status + \"</p>\"
            deletelink += \"<a href=devicedelete?device=\" + deviceIdPassed + \">here</a>.  Device will instantly be removed.</p>\"
        }
        // update result div on page
        \$(\"#header\").html(header)
        \$(\"#detail\").html(detail)
        \$(\"#delete\").html(deletelink)
    }

    // draw the graph
    window.onload = function () {

        //request the data from the API based on the device ID
        \$.getJSON(\"http://localhost:3000/sensor/\" + deviceIdPassed, addData);

        // array use dot store data
        var dataPoints = [];

        var chart = new CanvasJS.Chart(\"chartContainer\", {
            animationEnabled: true,
            //zoomEnabled: true,
            theme: \"light2\",
            title: {
                text: \"Temperature\"
            },
            axisY: {
                title: \"Degrees C°\",
                titleFontSize: 24,
                includeZero: false,

            },
            data: [{
                type: \"line\",
                yValueFormatString: \"#,### C°\",
                dataPoints: dataPoints
            }]
        });

        // write data to datapoints array (used to draw graph) then draw 
        function addData(data) {
            for (var i = 0; i < data.length; i++) {
                dataPoints.push({
                    x: new Date(data[i].date),
                    y: data[i].value
                });
            }
            chart.render();

        }



    }
</script>


<p>
<div id=\"header\"></div>

<p>View all devices <a href=\"{{ 'devices'|page }}\">here</a></p>
<div id=\"detail\"></div>






<h2>Current Status</h2>
<p>
<div id=\"chartContainer\" style=\"height: 300px; width: 100%;\"></div>
<p></p>
<p>You can delete devices, just please dont' delete devices 1,2,or 3, please add one then delete it</p>


<div id=\"delete\"></div>

</p>", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\chartData.htm", "");
    }
}
