<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\partials\addDevice.htm */
class __TwigTemplate_23eb009efb1991f58ae89617386195a331bbe6ad7e7b615e6f9d2c38d06a0b6f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<script src=\"https://unpkg.com/axios/dist/axios.min.js\"></script>

<div>

    <div id=\"deviceadded\"></div>

    <!-- <form id=\"addDevice\" name=\"addDevice\" action=\"\"> -->
    <div class=\"form-group\">
        <label class=\"\" for=\"device\">Device</label>

        <input type=\"text\" id=\"device\" class=\"form-control\" value=\"\" name=\"device\" minlength=\"5\" maxlength=\"20\"
            placeholder=\"Device Type / Name\" required />
    </div>

    <div class=\"form-group\">
        <label for=\"version\">Version</label>
        <input type=\"text\" id=\"version\" class=\"form-control\" value=\"\" name=\"version\" minlength=\"5\"
            placeholder=\"Version, eg 2.01\" maxlength=\"20\" required />

    </div>

    <div class=\"form-group\">
        <label for=\"status\">Status</label>
        <input type=\"text\" id=\"status\" class=\"form-control\" name=\"status\" value=\"\" minlength=\"1\" placeholder=\"0 or 1\"
            maxlength=\"1\" pattern=\"[0-1]{1}\" required oninvalid=\"this.setCustomValidity('you must enter 0 or 1')\"
            oninput=\"this.setCustomValidity('')\" /></br>

    </div>
    <div id=\"errordevice\"></div>
    <div id=\"errorversion\"></div>
    <div id=\"errornumber\"></div>


    <button id=\"addDevice\">Add New Device</button>
    <div id=\"deviceadded\"></div>
</div>



<script type=\"text/javascript\">
    // my listeners 
    \$(function () {

        //click add fire Ajax add device call then clear form
        \$(\"#addDevice\").on(\"click\", function () {

            //var passed = ValidInputs();

            if (ValidInputs()) {

                AddDevice();
                DeviceAdded(true);
                ClearAddDevice();

            }

            else {
                DeviceAdded(false);
                //DeviceAdded();

            }


        });
    });

    function ValidInputs() {


        var deviceInput = document.getElementById('device').value + \"\";
        var versionInput = document.getElementById('version').value + \"\";
        var statusInput = document.getElementById('status').value + \"\";

        var validDevice = ValidText(deviceInput, \"errordevice\", \"Device\");
        var validVersion = ValidText(versionInput, \"errorversion\", \"Version\");
        var validStatus = ValidNumber(statusInput);

        if (validDevice && validVersion && validStatus) {
            return true;
        } else {
            return false;
        }
    }






    function ValidNumber(number) {

        // If x is Not a Number or less than one or greater than 10
        if (isNaN(number) || number < 0 || number > 1 || number == \"\") {
            \$(\"#errornumber\").html(\"<p>Status is invalid (0 or 1)</p>\");
            return false;
        } else {
            \$(\"#errornumber\").html(\"\");
            return true;
        }
    }
    function ValidText(string, fieldname, displayname) {

        // If x is Not a Number or less than one or greater than 10
        if (string.length < 5 || ValidCharacters(string, fieldname, displayname)) {
            \$(\"#\" + fieldname).html(\"<p>\" + displayname + \" to be between 5 and 20 characters only letters, numbers and _-</p>\");
            return false;
        }

        else {
            \$(\"#\" + fieldname).html(\"\");
            return true;
        }
    }
    function ValidCharacters(deviceInput) {
        var iChars = \"!@#\$%^&*()+=-[]\\\\\\';,./{}|\\\":<>?\";

        for (var i = 0; i < deviceInput.length; i++) {
            if (iChars.indexOf(deviceInput.charAt(i)) != -1) {
                return true;
            }
            else { return false }

        }
    }






    function ClearAddDevice() {

        document.getElementById('device').value = '';
        document.getElementById('version').value = '';
        document.getElementById('status').value = '';
    }

    function AddDevice() {
        const json = JSON.stringify({ 'device': document.getElementById('device').value, 'version': document.getElementById('version').value, 'status': document.getElementById('status').value });
        const res = axios.post('http://localhost:3000/device/', json, {
            headers: {
                // Overwrite Axios's automatically set Content-Type
                'Content-Type': 'application/json',
                'Authorization': getCookie(\"lock\")
            }
        });


    }
    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }






    //get the details of the device
    function DeviceAdded(show) {
        if (show==true){
        var device = document.getElementById('device').value;
        // update result div on page
        \$(\"#deviceadded\").html(\"<p>New device added: \" + device + \"<p>\");
        }
        else{
            \$(\"#deviceadded\").html(\"<p>Invalid inputs</p>\");
        }
    }

</script>

</script>";
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\addDevice.htm";
    }

    public function getDebugInfo()
    {
        return array (  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<script src=\"https://unpkg.com/axios/dist/axios.min.js\"></script>

<div>

    <div id=\"deviceadded\"></div>

    <!-- <form id=\"addDevice\" name=\"addDevice\" action=\"\"> -->
    <div class=\"form-group\">
        <label class=\"\" for=\"device\">Device</label>

        <input type=\"text\" id=\"device\" class=\"form-control\" value=\"\" name=\"device\" minlength=\"5\" maxlength=\"20\"
            placeholder=\"Device Type / Name\" required />
    </div>

    <div class=\"form-group\">
        <label for=\"version\">Version</label>
        <input type=\"text\" id=\"version\" class=\"form-control\" value=\"\" name=\"version\" minlength=\"5\"
            placeholder=\"Version, eg 2.01\" maxlength=\"20\" required />

    </div>

    <div class=\"form-group\">
        <label for=\"status\">Status</label>
        <input type=\"text\" id=\"status\" class=\"form-control\" name=\"status\" value=\"\" minlength=\"1\" placeholder=\"0 or 1\"
            maxlength=\"1\" pattern=\"[0-1]{1}\" required oninvalid=\"this.setCustomValidity('you must enter 0 or 1')\"
            oninput=\"this.setCustomValidity('')\" /></br>

    </div>
    <div id=\"errordevice\"></div>
    <div id=\"errorversion\"></div>
    <div id=\"errornumber\"></div>


    <button id=\"addDevice\">Add New Device</button>
    <div id=\"deviceadded\"></div>
</div>



<script type=\"text/javascript\">
    // my listeners 
    \$(function () {

        //click add fire Ajax add device call then clear form
        \$(\"#addDevice\").on(\"click\", function () {

            //var passed = ValidInputs();

            if (ValidInputs()) {

                AddDevice();
                DeviceAdded(true);
                ClearAddDevice();

            }

            else {
                DeviceAdded(false);
                //DeviceAdded();

            }


        });
    });

    function ValidInputs() {


        var deviceInput = document.getElementById('device').value + \"\";
        var versionInput = document.getElementById('version').value + \"\";
        var statusInput = document.getElementById('status').value + \"\";

        var validDevice = ValidText(deviceInput, \"errordevice\", \"Device\");
        var validVersion = ValidText(versionInput, \"errorversion\", \"Version\");
        var validStatus = ValidNumber(statusInput);

        if (validDevice && validVersion && validStatus) {
            return true;
        } else {
            return false;
        }
    }






    function ValidNumber(number) {

        // If x is Not a Number or less than one or greater than 10
        if (isNaN(number) || number < 0 || number > 1 || number == \"\") {
            \$(\"#errornumber\").html(\"<p>Status is invalid (0 or 1)</p>\");
            return false;
        } else {
            \$(\"#errornumber\").html(\"\");
            return true;
        }
    }
    function ValidText(string, fieldname, displayname) {

        // If x is Not a Number or less than one or greater than 10
        if (string.length < 5 || ValidCharacters(string, fieldname, displayname)) {
            \$(\"#\" + fieldname).html(\"<p>\" + displayname + \" to be between 5 and 20 characters only letters, numbers and _-</p>\");
            return false;
        }

        else {
            \$(\"#\" + fieldname).html(\"\");
            return true;
        }
    }
    function ValidCharacters(deviceInput) {
        var iChars = \"!@#\$%^&*()+=-[]\\\\\\';,./{}|\\\":<>?\";

        for (var i = 0; i < deviceInput.length; i++) {
            if (iChars.indexOf(deviceInput.charAt(i)) != -1) {
                return true;
            }
            else { return false }

        }
    }






    function ClearAddDevice() {

        document.getElementById('device').value = '';
        document.getElementById('version').value = '';
        document.getElementById('status').value = '';
    }

    function AddDevice() {
        const json = JSON.stringify({ 'device': document.getElementById('device').value, 'version': document.getElementById('version').value, 'status': document.getElementById('status').value });
        const res = axios.post('http://localhost:3000/device/', json, {
            headers: {
                // Overwrite Axios's automatically set Content-Type
                'Content-Type': 'application/json',
                'Authorization': getCookie(\"lock\")
            }
        });


    }
    function getCookie(cname) {
        var name = cname + \"=\";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return \"\";
    }






    //get the details of the device
    function DeviceAdded(show) {
        if (show==true){
        var device = document.getElementById('device').value;
        // update result div on page
        \$(\"#deviceadded\").html(\"<p>New device added: \" + device + \"<p>\");
        }
        else{
            \$(\"#deviceadded\").html(\"<p>Invalid inputs</p>\");
        }
    }

</script>

</script>", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\addDevice.htm", "");
    }
}
