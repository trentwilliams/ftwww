<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* D:\DEV\XAMPP\htdocs\ftwww\themes\demo\partials\apisignin.htm */
class __TwigTemplate_0da2bcf36686a4d7aa4a82ef0d5f5314a04ff134321a52a58c97c1ec9e28fc39 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<h1>api sign in</h1>
<p>this page has just done a sign in wtih the API and recorded </p>

<script src=\"https://unpkg.com/axios/dist/axios.min.js\"></script>



<script type=\"text/javascript\">

  //  apiSignIn();


    async function apiSignIn() {
        const json = JSON.stringify({ 'email': 'trent@trentkels.com', 'apipw': 'pw1234' });

        let res = await axios.post('http://localhost:3000/user/', json, {
            headers: {
                // Overwrite Axios's automatically set Content-Type
                'Content-Type': 'application/json'
            }



        });


        //let data = res.data;
        //let token=data.token;
        //console.log(`Data: \${data}`);
        //console.log(data);
        //console.log(token);
        //document.cookie = res;
        //setCookie(\"lock\", \"Bearer \" + res.data.token, 1);

    }


    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = \"expires=\" + d.toUTCString();
        document.cookie = cname + \"=\" + cvalue + \";\" + expires + \";path=/\";
    }

</script>";
    }

    public function getTemplateName()
    {
        return "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\apisignin.htm";
    }

    public function getDebugInfo()
    {
        return array (  62 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<h1>api sign in</h1>
<p>this page has just done a sign in wtih the API and recorded </p>

<script src=\"https://unpkg.com/axios/dist/axios.min.js\"></script>



<script type=\"text/javascript\">

  //  apiSignIn();


    async function apiSignIn() {
        const json = JSON.stringify({ 'email': 'trent@trentkels.com', 'apipw': 'pw1234' });

        let res = await axios.post('http://localhost:3000/user/', json, {
            headers: {
                // Overwrite Axios's automatically set Content-Type
                'Content-Type': 'application/json'
            }



        });


        //let data = res.data;
        //let token=data.token;
        //console.log(`Data: \${data}`);
        //console.log(data);
        //console.log(token);
        //document.cookie = res;
        //setCookie(\"lock\", \"Bearer \" + res.data.token, 1);

    }


    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = \"expires=\" + d.toUTCString();
        document.cookie = cname + \"=\" + cvalue + \";\" + expires + \";path=/\";
    }

</script>", "D:\\DEV\\XAMPP\\htdocs\\ftwww\\themes\\demo\\partials\\apisignin.htm", "");
    }
}
