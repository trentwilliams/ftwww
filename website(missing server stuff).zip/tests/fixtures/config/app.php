<?php
// Fixture used for `october:env` unit tests in `tests/unit/system/console/OctoberEnvTest.php

return [
    'debug' => true,
    'url' => 'https://localhost',
    'key' => 'CHANGE_ME!!!!!!!!!!!!!!!!!!!!!!!',
    'timezone' => 'UTC',
];
