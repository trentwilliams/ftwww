<?php
// Fixture used for `october:env` unit tests in `tests/unit/system/console/OctoberEnvTest.php

return [
    'driver' => 'smtp',
    'host' => 'smtp.mailgun.org',
    'port' => 587,
    'encryption' => 'tls',
    'username' => null,
    'password' => null,
];
