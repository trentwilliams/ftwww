<?php
// Fixture used for `october:env` unit tests in `tests/unit/system/console/OctoberEnvTest.php

return [
    'default' => 'sync',
];
