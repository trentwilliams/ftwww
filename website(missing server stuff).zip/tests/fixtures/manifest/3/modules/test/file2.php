<?php
// file2.php - version 2.
