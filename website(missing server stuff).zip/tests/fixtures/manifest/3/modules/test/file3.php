<?php
// file3.php - version 1.
