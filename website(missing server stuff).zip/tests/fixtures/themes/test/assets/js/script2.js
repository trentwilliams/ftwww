console.log('script2.js');
