console.log('subdir/script1.js');
